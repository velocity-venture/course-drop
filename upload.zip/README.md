# Unconventional Wisdom - Course Portal

A custom, self-hosted course portal for the 16-week business book program.

## 🎨 Design: "Private Athenaeum"

- **Dark Mode**: Midnight background (#0a0a0a)
- **Gold Accents**: (#c9a227)
- **Serif Typography**: Playfair Display for headings
- **Sans Typography**: Inter for body text

## 📁 Project Structure

```
course-portal/
├── app/
│   ├── globals.css          # Global styles & Tailwind
│   ├── layout.tsx           # Root layout
│   └── learn/
│       ├── page.tsx         # Dashboard (Library View)
│       └── [slug]/
│           └── page.tsx     # Book Detail Page
├── components/
│   └── CourseSidebar.tsx    # Navigation sidebar
├── lib/
│   └── books.ts             # Book data (all 16 weeks)
├── package.json
├── tailwind.config.ts
├── tsconfig.json
├── postcss.config.js
└── next.config.js
```

## 🚀 Quick Start

### 1. Install Dependencies

```bash
npm install
```

### 2. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000/learn](http://localhost:3000/learn)

### 3. Build for Production

```bash
npm run build
```

### 4. Start Production Server

```bash
npm start
```

## 🖥️ Hostinger VPS Deployment

### Option A: Using PM2 (Recommended)

```bash
# SSH into your VPS
ssh user@your-vps-ip

# Clone or upload the project
cd /var/www
git clone your-repo-url unconventional-wisdom
cd unconventional-wisdom

# Install dependencies
npm install

# Build the project
npm run build

# Install PM2 globally
npm install -g pm2

# Start with PM2
pm2 start npm --name "uw-portal" -- start

# Save PM2 process list
pm2 save

# Set PM2 to start on boot
pm2 startup
```

### Option B: Using Docker

```dockerfile
# Dockerfile
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:18-alpine AS runner
WORKDIR /app
ENV NODE_ENV production
COPY --from=builder /app/.next/standalone ./
COPY --from=builder /app/.next/static ./.next/static
COPY --from=builder /app/public ./public
EXPOSE 3000
CMD ["node", "server.js"]
```

```bash
# Build and run
docker build -t uw-portal .
docker run -p 3000:3000 uw-portal
```

### Nginx Reverse Proxy

```nginx
# /etc/nginx/sites-available/uw-portal
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Enable the site
sudo ln -s /etc/nginx/sites-available/uw-portal /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### SSL with Certbot

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

## 📚 Book Status Management

In `lib/books.ts`, each book has a `status` field:

- `'active'` - Currently available
- `'locked'` - Not yet unlocked
- `'completed'` - User has finished

To unlock books based on date or user progress, modify the status logic in the data file or add a backend API.

## 🎯 Features

- ✅ 16-week curriculum display
- ✅ Book detail pages with full content
- ✅ Collapsible sidebar navigation
- ✅ Progress tracking
- ✅ Locked/Active/Completed states
- ✅ Responsive design
- ✅ Marble & Gold aesthetic

## 🔧 Customization

### Change Colors

Edit `tailwind.config.ts` and `app/globals.css`:

```css
:root {
  --color-gold: #c9a227;      /* Change this */
  --color-midnight: #0a0a0a;  /* Change this */
}
```

### Add Authentication

Integrate with:
- NextAuth.js
- Clerk
- Auth0
- Custom JWT

### Add Assignment Submission

1. Create API routes in `app/api/`
2. Add form handling to book detail pages
3. Connect to database (PostgreSQL, MongoDB, etc.)

## 📝 License

Proprietary - Velocity Venture Holdings, LLC

---

Built by Sayada.ai | Unconventional Wisdom Program
