// app/learn/[slug]/page.tsx
// Unconventional Wisdom - Book Detail Page

import { notFound } from 'next/navigation';
import Link from 'next/link';
import { 
  ArrowLeft, 
  Book, 
  Clock, 
  CheckCircle, 
  Quote, 
  Target,
  Lightbulb,
  BookOpen,
  FileText,
  ChevronRight,
  Lock
} from 'lucide-react';
import { books, getBookBySlug, getAllSlugs } from '@/lib/books';
import CourseSidebar from '@/components/CourseSidebar';

// Generate static params for all books
export async function generateStaticParams() {
  return getAllSlugs().map((slug) => ({
    slug: slug,
  }));
}

// Page component
export default function BookDetailPage({ params }: { params: { slug: string } }) {
  const book = getBookBySlug(params.slug);
  
  if (!book) {
    notFound();
  }

  const isLocked = book.status === 'locked';
  const isCompleted = book.status === 'completed';
  
  // Get next and previous books
  const currentIndex = books.findIndex(b => b.slug === params.slug);
  const prevBook = currentIndex > 0 ? books[currentIndex - 1] : null;
  const nextBook = currentIndex < books.length - 1 ? books[currentIndex + 1] : null;

  if (isLocked) {
    return <LockedBookPage book={book} />;
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#f5f5f0]">
      {/* Header */}
      <header className="border-b border-[#c9a227]/20 bg-[#0a0a0a]/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link 
            href="/learn" 
            className="flex items-center gap-2 text-[#f5f5f0]/60 hover:text-[#c9a227] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">Back to Library</span>
          </Link>
          
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-[#c9a227] to-[#a68520] rounded-lg flex items-center justify-center">
              <BookOpen className="w-4 h-4 text-[#0a0a0a]" />
            </div>
            <span className="font-serif text-sm tracking-wide">Unconventional Wisdom</span>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <CourseSidebar currentSlug={params.slug} />

        {/* Main Content */}
        <main className="flex-1 max-w-4xl mx-auto px-8 py-12">
          {/* Book Header */}
          <div className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <span className={`
                px-3 py-1 rounded-full text-xs font-medium tracking-wider uppercase
                ${isCompleted 
                  ? 'bg-[#c9a227] text-[#0a0a0a]' 
                  : 'bg-[#c9a227]/20 text-[#c9a227] border border-[#c9a227]/30'
                }
              `}>
                {book.week === 0 ? 'Introduction' : `Week ${book.week}`}
              </span>
              <span className="text-[#f5f5f0]/30">•</span>
              <span className="text-sm text-[#c9a227]">{book.theme}</span>
            </div>

            <h1 className="font-serif text-5xl font-light mb-4 leading-tight">
              {book.title}
            </h1>
            
            <p className="text-xl text-[#f5f5f0]/60 mb-6">
              by <span className="text-[#c9a227]">{book.author}</span>
            </p>

            <p className="text-lg text-[#f5f5f0]/70 leading-relaxed italic border-l-2 border-[#c9a227] pl-4">
              {book.hook}
            </p>

            {/* Meta Stats */}
            {book.week !== 0 && (
              <div className="flex items-center gap-6 mt-8 pt-6 border-t border-[#c9a227]/10">
                <div className="flex items-center gap-2 text-[#f5f5f0]/50">
                  <Book className="w-4 h-4" />
                  <span>{book.pages} pages</span>
                </div>
                <div className="flex items-center gap-2 text-[#f5f5f0]/50">
                  <Clock className="w-4 h-4" />
                  <span>{book.audioHours} audiobook</span>
                </div>
                {isCompleted && (
                  <div className="flex items-center gap-2 text-[#c9a227]">
                    <CheckCircle className="w-4 h-4" />
                    <span>Completed</span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Why This Book Section */}
          <Section 
            icon={<Lightbulb className="w-5 h-5" />}
            title="Why This Book Is Unconventional"
          >
            <p className="text-[#f5f5f0]/70 leading-relaxed">
              {book.whyUnconventional}
            </p>
          </Section>

          {/* The Big Idea */}
          <Section 
            icon={<Target className="w-5 h-5" />}
            title="The Big Idea"
          >
            <p className="text-[#f5f5f0]/70 leading-relaxed mb-6">
              {book.bigIdea}
            </p>
            <blockquote className="bg-[#111111] border-l-4 border-[#c9a227] p-6 rounded-r-xl">
              <Quote className="w-6 h-6 text-[#c9a227]/40 mb-3" />
              <p className="font-serif text-xl text-[#f5f5f0] italic leading-relaxed">
                "{book.bigIdeaQuote}"
              </p>
              <cite className="text-sm text-[#f5f5f0]/40 mt-3 block">— {book.author}</cite>
            </blockquote>
          </Section>

          {/* Key Concepts */}
          <Section 
            icon={<BookOpen className="w-5 h-5" />}
            title="Key Concepts"
          >
            <div className="grid gap-4">
              {book.keyConcepts.map((concept, index) => (
                <div 
                  key={index}
                  className="bg-[#111111] border border-[#c9a227]/10 rounded-xl p-5 hover:border-[#c9a227]/30 transition-colors"
                >
                  <h4 className="font-serif text-lg text-[#c9a227] mb-2">{concept.title}</h4>
                  <p className="text-[#f5f5f0]/60 leading-relaxed">{concept.description}</p>
                </div>
              ))}
            </div>
          </Section>

          {/* Case Study */}
          <Section 
            icon={<FileText className="w-5 h-5" />}
            title={`Case Study: ${book.caseStudy.title}`}
          >
            <div className="bg-gradient-to-br from-[#111111] to-[#0a0a0a] border border-[#c9a227]/20 rounded-xl p-6">
              <p className="text-[#f5f5f0]/70 leading-relaxed whitespace-pre-line">
                {book.caseStudy.content}
              </p>
            </div>
          </Section>

          {/* Key Principles */}
          <Section 
            icon={<Target className="w-5 h-5" />}
            title="Key Principles"
          >
            <div className="space-y-4">
              {book.keyPrinciples.map((principle, index) => (
                <div key={index} className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-[#c9a227]/10 border border-[#c9a227]/20 rounded-full flex items-center justify-center">
                    <span className="text-[#c9a227] text-sm font-medium">{index + 1}</span>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-serif text-lg text-[#f5f5f0] mb-1">{principle.title}</h4>
                    <p className="text-[#f5f5f0]/50 leading-relaxed">{principle.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </Section>

          {/* Quotable Quotes */}
          <Section 
            icon={<Quote className="w-5 h-5" />}
            title="Quotable Quotes"
          >
            <div className="space-y-4">
              {book.quotes.map((quote, index) => (
                <div 
                  key={index}
                  className="bg-[#111111] border border-[#c9a227]/10 rounded-xl p-5 hover:bg-[#c9a227]/5 transition-colors"
                >
                  <p className="font-serif text-lg text-[#f5f5f0]/80 italic">
                    "{quote}"
                  </p>
                </div>
              ))}
            </div>
          </Section>

          {/* Assignment */}
          <div className="bg-gradient-to-br from-[#c9a227]/10 to-[#c9a227]/5 border border-[#c9a227]/30 rounded-2xl p-8 mt-12">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-[#c9a227] rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-[#0a0a0a]" />
              </div>
              <div>
                <p className="text-xs text-[#c9a227] uppercase tracking-wider">Week {book.week} Assignment</p>
                <h3 className="font-serif text-2xl">{book.assignment.title}</h3>
              </div>
            </div>

            <p className="text-[#f5f5f0]/70 leading-relaxed mb-6">
              {book.assignment.description}
            </p>

            <div className="space-y-3">
              {book.assignment.tasks.map((task, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-[#0a0a0a] border border-[#c9a227]/30 rounded flex items-center justify-center mt-0.5">
                    <span className="text-[#c9a227] text-xs">{index + 1}</span>
                  </div>
                  <p className="text-[#f5f5f0]/60">{task}</p>
                </div>
              ))}
            </div>

            <button className="mt-8 w-full bg-[#c9a227] hover:bg-[#e8c547] text-[#0a0a0a] font-semibold py-4 px-6 rounded-xl transition-colors">
              Mark Assignment Complete
            </button>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between mt-12 pt-8 border-t border-[#c9a227]/10">
            {prevBook ? (
              <Link 
                href={`/learn/${prevBook.slug}`}
                className="flex items-center gap-2 text-[#f5f5f0]/50 hover:text-[#c9a227] transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                <span className="text-sm">Week {prevBook.week}: {prevBook.title}</span>
              </Link>
            ) : <div />}
            
            {nextBook ? (
              <Link 
                href={nextBook.status === 'locked' ? '#' : `/learn/${nextBook.slug}`}
                className={`flex items-center gap-2 transition-colors ${
                  nextBook.status === 'locked' 
                    ? 'text-[#f5f5f0]/20 cursor-not-allowed' 
                    : 'text-[#f5f5f0]/50 hover:text-[#c9a227]'
                }`}
              >
                <span className="text-sm">Week {nextBook.week}: {nextBook.title}</span>
                {nextBook.status === 'locked' ? (
                  <Lock className="w-4 h-4" />
                ) : (
                  <ChevronRight className="w-4 h-4" />
                )}
              </Link>
            ) : <div />}
          </div>
        </main>
      </div>
    </div>
  );
}

// Section Component
function Section({ 
  icon, 
  title, 
  children 
}: { 
  icon: React.ReactNode;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="mb-12">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-8 h-8 bg-[#c9a227]/10 border border-[#c9a227]/20 rounded-lg flex items-center justify-center text-[#c9a227]">
          {icon}
        </div>
        <h2 className="font-serif text-2xl">{title}</h2>
      </div>
      {children}
    </section>
  );
}

// Locked Book Page
function LockedBookPage({ book }: { book: typeof books[0] }) {
  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#f5f5f0]">
      {/* Header */}
      <header className="border-b border-[#c9a227]/20 bg-[#0a0a0a]/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link 
            href="/learn" 
            className="flex items-center gap-2 text-[#f5f5f0]/60 hover:text-[#c9a227] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">Back to Library</span>
          </Link>
          
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-[#c9a227] to-[#a68520] rounded-lg flex items-center justify-center">
              <BookOpen className="w-4 h-4 text-[#0a0a0a]" />
            </div>
            <span className="font-serif text-sm tracking-wide">Unconventional Wisdom</span>
          </div>
        </div>
      </header>

      <div className="flex">
        <CourseSidebar currentSlug={book.slug} />
        
        <main className="flex-1 flex items-center justify-center px-8 py-24">
          <div className="text-center max-w-lg">
            <div className="w-20 h-20 bg-[#111111] border border-[#c9a227]/20 rounded-2xl flex items-center justify-center mx-auto mb-8">
              <Lock className="w-10 h-10 text-[#f5f5f0]/30" />
            </div>
            
            <span className="px-3 py-1 rounded-full text-xs font-medium tracking-wider uppercase bg-[#1a1a1a] text-[#f5f5f0]/40 mb-4 inline-block">
              Week {book.week}
            </span>
            
            <h1 className="font-serif text-4xl font-light mb-4 text-[#f5f5f0]/50">
              {book.title}
            </h1>
            
            <p className="text-[#f5f5f0]/30 mb-8">
              by {book.author}
            </p>
            
            <p className="text-[#f5f5f0]/40 leading-relaxed mb-8">
              This content will unlock when you reach Week {book.week}. 
              Complete the previous weeks to continue your journey.
            </p>
            
            <Link 
              href="/learn"
              className="inline-flex items-center gap-2 bg-[#c9a227]/10 border border-[#c9a227]/30 text-[#c9a227] px-6 py-3 rounded-xl hover:bg-[#c9a227]/20 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Return to Library
            </Link>
          </div>
        </main>
      </div>
    </div>
  );
}
