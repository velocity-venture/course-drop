/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['localhost'],
    unoptimized: true, // For static export if needed
  },
  // For Hostinger VPS deployment
  output: 'standalone',
};

module.exports = nextConfig;
