// lib/books.ts
// Unconventional Wisdom - 16 Week Course Data

export type BookStatus = 'active' | 'locked' | 'completed';

export interface Book {
  week: number;
  slug: string;
  title: string;
  author: string;
  hook: string;
  theme: string;
  pages: number;
  audioHours: string;
  status: BookStatus;
  summary: string;
  whyUnconventional: string;
  bigIdea: string;
  bigIdeaQuote: string;
  keyConcepts: {
    title: string;
    description: string;
  }[];
  caseStudy: {
    title: string;
    content: string;
  };
  keyPrinciples: {
    title: string;
    description: string;
  }[];
  quotes: string[];
  assignment: {
    title: string;
    description: string;
    tasks: string[];
  };
}

export const books: Book[] = [
  {
    week: 0,
    slug: 'introduction',
    title: 'Welcome to Unconventional Wisdom',
    author: 'Your Journey Begins',
    hook: 'The 15 books business schools won\'t teach — and how to extract maximum value from each one.',
    theme: 'Program Introduction',
    pages: 0,
    audioHours: '0',
    status: 'active',
    summary: 'Welcome to the most intensive business reading program ever created. Over the next 16 weeks, you\'ll read 15 complete books that shaped how billionaires think. Not summaries. Not highlights. The full books.',
    whyUnconventional: 'Most business education focuses on theory. We focus on the hard-won lessons of people who actually built empires.',
    bigIdea: 'The best business education doesn\'t come from professors — it comes from practitioners who\'ve survived the arena.',
    bigIdeaQuote: 'The reading of all good books is like a conversation with the finest minds of past centuries. — René Descartes',
    keyConcepts: [
      {
        title: 'The $300 Completion Guarantee',
        description: 'Complete all 15 assignments and receive $300 cash back. We\'re betting on your commitment.'
      },
      {
        title: 'The Weekly Rhythm',
        description: 'One book per week. Read it. Study the content pack. Complete the assignment. Repeat.'
      },
      {
        title: 'Time Commitment',
        description: '2-3 hours per day. This is a serious program for serious people.'
      },
      {
        title: 'Implementation Focus',
        description: 'Every assignment forces you to apply the concepts to YOUR business or career.'
      }
    ],
    caseStudy: {
      title: 'Why This Program Exists',
      content: 'The average online course has a 3-15% completion rate. That\'s embarrassing. People pay, they don\'t finish, and they feel guilty. We\'re changing that with skin in the game — yours AND ours.'
    },
    keyPrinciples: [
      {
        title: 'Read the Full Book',
        description: 'No summaries. No shortcuts. The transformation happens in the pages you want to skip.'
      },
      {
        title: 'Do the Assignment',
        description: 'Reading without implementation is entertainment. Implementation is transformation.'
      },
      {
        title: 'Stay on Schedule',
        description: 'Falling behind compounds fast. Protect your reading time like the investment it is.'
      },
      {
        title: 'Embrace Discomfort',
        description: 'Some books will challenge your assumptions. That\'s the point.'
      },
      {
        title: 'Finish What You Start',
        description: 'The $300 is nice. The person you become by finishing is priceless.'
      }
    ],
    quotes: [
      'The reading of all good books is like a conversation with the finest minds of past centuries.',
      'In my whole life, I have known no wise people who didn\'t read all the time — none, zero.',
      'The more that you read, the more things you will know. The more that you learn, the more places you\'ll go.'
    ],
    assignment: {
      title: 'Program Preparation',
      description: 'Set yourself up for success over the next 16 weeks.',
      tasks: [
        'Block 2-3 hours daily in your calendar for the next 16 weeks',
        'Acquire Week 1 book: "Only the Paranoid Survive" by Andy Grove',
        'Set up your reading environment (physical space, apps, audiobook setup)',
        'Write down your #1 goal for completing this program',
        'Tell one person about your commitment (accountability partner)'
      ]
    }
  },
  {
    week: 1,
    slug: 'only-the-paranoid-survive',
    title: 'Only the Paranoid Survive',
    author: 'Andy Grove',
    hook: 'The book that saved Intel from bankruptcy — and will teach you to see disruption before it destroys you.',
    theme: 'Strategic Inflection Points',
    pages: 210,
    audioHours: '5h 15m',
    status: 'locked',
    summary: 'Andy Grove, the legendary CEO of Intel, reveals how to identify and navigate the critical moments when the fundamentals of business change. These "Strategic Inflection Points" can either destroy your company or catapult it to new heights.',
    whyUnconventional: 'Business schools teach stability and optimization. Grove teaches that your greatest success contains the seeds of your destruction — and only paranoid vigilance keeps you alive.',
    bigIdea: 'Every business faces moments when the fundamental rules of competition change. The companies that survive aren\'t lucky. They\'re paranoid.',
    bigIdeaQuote: 'Business success contains the seeds of its own destruction.',
    keyConcepts: [
      {
        title: 'Strategic Inflection Points (SIPs)',
        description: 'A 10x change in competitive forces that fundamentally rewrites the rules of your industry.'
      },
      {
        title: 'The Valley of Death',
        description: 'The fog of uncertainty when your old strategy fails but new direction isn\'t yet clear.'
      },
      {
        title: 'Helpful Cassandras',
        description: 'Front-line employees who see disruption coming before executives do.'
      },
      {
        title: 'Let Chaos Reign, Then Rein in Chaos',
        description: 'Encourage wild experimentation during uncertainty, then commit 100% once direction emerges.'
      }
    ],
    caseStudy: {
      title: 'Intel\'s Do-or-Die Pivot',
      content: 'In 1985, Intel was a memory company — they literally invented DRAM. But Japanese manufacturers were crushing them on price and quality. Grove asked co-founder Gordon Moore: "If we got kicked out and the board brought in a new CEO, what would he do?" Moore\'s answer: "Get us out of memories." Grove replied: "Why shouldn\'t you and I walk out the door, come back in, and do it ourselves?" They exited memory — the business they invented — and bet everything on microprocessors. Intel became the most valuable semiconductor company in history.'
    },
    keyPrinciples: [
      {
        title: 'Embrace Strategic Paranoia',
        description: 'Success breeds complacency. The moment you feel safe is the moment you\'re most vulnerable.'
      },
      {
        title: 'Listen to the Cassandras',
        description: 'Your sales reps, engineers, and customer service people see disruption coming before you do.'
      },
      {
        title: 'Let Chaos Reign (Temporarily)',
        description: 'During strategic uncertainty, encourage experimentation. But once direction is clear, commit totally.'
      },
      {
        title: 'Fire Yourself Mentally',
        description: 'Ask: "What would a new CEO do?" Remove emotional attachment to see the obvious answer.'
      },
      {
        title: 'Cannibalize Yourself',
        description: 'If you don\'t destroy your own business model, someone else will.'
      }
    ],
    quotes: [
      'Only the paranoid survive.',
      'Business success contains the seeds of its own destruction.',
      'Let chaos reign, then rein in chaos.',
      'Most companies don\'t die because they are wrong; most die because they don\'t commit.',
      'You have to pretend to be confident when you\'re not.'
    ],
    assignment: {
      title: 'Strategic Inflection Point Audit',
      description: 'Analyze your business or industry for potential 10x disruptions.',
      tasks: [
        'Identify the 6 competitive forces in your industry (Porter\'s forces + complementors)',
        'Rate each force for likelihood of 10x change in the next 3 years',
        'Complete the "Fire Yourself" exercise: What would a new CEO do?',
        'Identify 3 "Cassandras" in your organization or network — schedule conversations with them',
        'Document one strategic bet you\'ve been avoiding because it feels too risky'
      ]
    }
  },
  {
    week: 2,
    slug: 'how-to-make-a-few-billion-dollars',
    title: 'How to Make a Few Billion Dollars',
    author: 'Brad Jacobs',
    hook: 'The serial billionaire\'s playbook for building massive companies through acquisition.',
    theme: 'Acquisition Strategy',
    pages: 304,
    audioHours: '9h 30m',
    status: 'locked',
    summary: 'Brad Jacobs has built seven multi-billion dollar companies across different industries. This is his playbook for identifying opportunities, structuring deals, and scaling through acquisition.',
    whyUnconventional: 'Most business books focus on organic growth. Jacobs reveals the acquisition-driven model that creates billionaires faster than any startup grind.',
    bigIdea: 'The fastest path to building a massive company isn\'t starting from scratch — it\'s buying existing businesses and making them better.',
    bigIdeaQuote: 'I\'ve never had an original idea in my life. I just take what works and apply it somewhere else.',
    keyConcepts: [
      {
        title: 'Platform Acquisitions',
        description: 'Buy a solid base company, then bolt on smaller acquisitions to create scale.'
      },
      {
        title: 'Fragmented Industries',
        description: 'Target industries with thousands of small players ripe for consolidation.'
      },
      {
        title: 'Management Upgrades',
        description: 'Most acquired companies improve dramatically with better management systems.'
      },
      {
        title: 'Capital Efficiency',
        description: 'Use other people\'s money strategically to amplify returns.'
      }
    ],
    caseStudy: {
      title: 'XPO Logistics: From Zero to $18 Billion',
      content: 'In 2011, Jacobs took over a small trucking company doing $175 million in revenue. Through 17 strategic acquisitions and operational improvements, he transformed it into XPO Logistics — an $18 billion transportation giant. The playbook: buy underperforming companies in fragmented industries, install world-class management, and integrate relentlessly.'
    },
    keyPrinciples: [
      {
        title: 'Hunt in Fragmented Markets',
        description: 'Industries with thousands of small players offer the best consolidation opportunities.'
      },
      {
        title: 'Management is Everything',
        description: 'The same business can 10x with better leadership and systems.'
      },
      {
        title: 'Move Fast, Integrate Faster',
        description: 'Speed of integration determines success. Don\'t let acquired companies languish.'
      },
      {
        title: 'Use Leverage Wisely',
        description: 'Debt is a tool. Use it to amplify returns, but never bet the company.'
      },
      {
        title: 'Think in Decades',
        description: 'Build for long-term value, not quick flips.'
      }
    ],
    quotes: [
      'I\'ve never had an original idea in my life.',
      'The best time to buy is when others are scared.',
      'Management quality is the single biggest variable in business performance.',
      'Fragmented industries are gold mines waiting to be consolidated.',
      'Move fast. Integrate faster.'
    ],
    assignment: {
      title: 'Acquisition Opportunity Analysis',
      description: 'Identify a potential acquisition or consolidation play in your industry.',
      tasks: [
        'Map the fragmentation level of your industry (how many players, what % of market do top 10 control)',
        'Identify 3 potential acquisition targets that could accelerate your growth',
        'Calculate the rough math: What would 2-3 acquisitions do to your revenue and market position?',
        'List the management systems you would install in an acquired company',
        'Draft a one-page "roll-up thesis" for your industry'
      ]
    }
  },
  {
    week: 3,
    slug: 'am-i-being-too-subtle',
    title: 'Am I Being Too Subtle?',
    author: 'Sam Zell',
    hook: 'How a contrarian investor turned $10,000 into $5 billion by zigging when everyone else zagged.',
    theme: 'Contrarian Investing',
    pages: 256,
    audioHours: '8h 45m',
    status: 'locked',
    summary: 'Sam Zell built a real estate empire by doing the opposite of what everyone else was doing. This is his story of contrarian thinking, risk assessment, and unconventional deal-making.',
    whyUnconventional: 'While others chased hot markets, Zell bought when everyone was selling and sold when everyone was buying. His "grave dancer" approach created massive wealth.',
    bigIdea: 'The best opportunities exist where others see only problems. Contrarian thinking isn\'t just different — it\'s profitable.',
    bigIdeaQuote: 'If everyone is going left, look right.',
    keyConcepts: [
      {
        title: 'The Grave Dancer',
        description: 'Buy distressed assets when everyone else is running away. Dance on the graves of failed businesses.'
      },
      {
        title: 'Risk vs. Uncertainty',
        description: 'Risk can be measured; uncertainty cannot. Focus on risk you can quantify.'
      },
      {
        title: 'Supply and Demand',
        description: 'Everything comes down to supply and demand. Understand these dynamics before any investment.'
      },
      {
        title: 'Liquidity is Everything',
        description: 'Always maintain the ability to act when opportunities arise.'
      }
    ],
    caseStudy: {
      title: 'Buying the S&L Crisis',
      content: 'In the early 1990s, the Savings & Loan crisis left thousands of properties in distress. While other investors fled real estate entirely, Zell went on a buying spree. He purchased billions in distressed assets at pennies on the dollar. When the market recovered, those investments generated returns of 10x or more. His secret: understanding that the properties weren\'t worthless — they were just temporarily out of favor.'
    },
    keyPrinciples: [
      {
        title: 'Be a Contrarian',
        description: 'If everyone agrees, you\'re probably too late. The best deals are controversial.'
      },
      {
        title: 'Understand Real Risk',
        description: 'Most people confuse uncertainty with risk. Learn to separate them.'
      },
      {
        title: 'Keep Liquidity',
        description: 'You can\'t take advantage of opportunities if you\'re fully invested.'
      },
      {
        title: 'Focus on Fundamentals',
        description: 'Ignore the noise. What matters is supply, demand, and cash flow.'
      },
      {
        title: 'Be Direct',
        description: 'Subtlety is overrated. Say what you mean and mean what you say.'
      }
    ],
    quotes: [
      'If everyone is going left, look right.',
      'I\'ve spent my career trying to find the opportunity in the problem.',
      'Liquidity equals value.',
      'Risk is not knowing what you\'re doing.',
      'The definition of an entrepreneur is someone who works 80 hours a week to avoid working 40 hours for someone else.'
    ],
    assignment: {
      title: 'Contrarian Opportunity Hunt',
      description: 'Find opportunities others are ignoring or fleeing from.',
      tasks: [
        'Identify 3 industries or assets currently out of favor (what is everyone avoiding?)',
        'For each, analyze: Is this a temporary problem or permanent decline?',
        'Calculate the supply/demand dynamics of one distressed opportunity',
        'List the reasons everyone is avoiding it — then challenge each assumption',
        'Create a "contrarian watchlist" of opportunities to revisit in 6 months'
      ]
    }
  },
  {
    week: 4,
    slug: 'extreme-ownership',
    title: 'Extreme Ownership',
    author: 'Jocko Willink & Leif Babin',
    hook: 'Navy SEAL leadership principles forged in the deadliest urban combat — applied to business.',
    theme: 'Leadership',
    pages: 320,
    audioHours: '8h 25m',
    status: 'locked',
    summary: 'Two Navy SEAL officers who led the most decorated special operations unit of the Iraq War share the leadership principles that work in combat and boardrooms alike.',
    whyUnconventional: 'Most leadership books coddle. This one demands absolute accountability — for everything, from everyone, starting with yourself.',
    bigIdea: 'Leaders must own everything in their world. There is no one else to blame.',
    bigIdeaQuote: 'The leader is always responsible. There are no bad teams, only bad leaders.',
    keyConcepts: [
      {
        title: 'Extreme Ownership',
        description: 'Leaders take complete responsibility for everything — no excuses, no blame.'
      },
      {
        title: 'Cover and Move',
        description: 'Teams must work together, supporting each other to accomplish the mission.'
      },
      {
        title: 'Simple',
        description: 'Plans and orders must be simple enough that everyone understands.'
      },
      {
        title: 'Prioritize and Execute',
        description: 'When overwhelmed, focus on the highest priority task, then move to the next.'
      }
    ],
    caseStudy: {
      title: 'The Battle of Ramadi',
      content: 'In 2006, Ramadi was the most dangerous city in Iraq. Jocko\'s SEAL Task Unit Bruiser was tasked with taking it back. After a friendly fire incident that killed one of their own, Jocko faced a room full of superior officers looking for someone to blame. His response: "There is only one person to blame — me." That extreme ownership transformed the unit and led to their success in one of the most brutal urban combat environments in modern warfare.'
    },
    keyPrinciples: [
      {
        title: 'Own Everything',
        description: 'If you\'re the leader, everything is your responsibility. Full stop.'
      },
      {
        title: 'No Bad Teams',
        description: 'When a team fails, it\'s leadership failure. Fix yourself first.'
      },
      {
        title: 'Keep Plans Simple',
        description: 'If it\'s too complex to explain quickly, it\'s too complex to execute.'
      },
      {
        title: 'Lead Up the Chain',
        description: 'If your boss doesn\'t understand your needs, that\'s your failure to communicate.'
      },
      {
        title: 'Discipline Equals Freedom',
        description: 'The more disciplined you are, the more freedom you earn.'
      }
    ],
    quotes: [
      'There are no bad teams, only bad leaders.',
      'Discipline equals freedom.',
      'It\'s not what you preach, it\'s what you tolerate.',
      'Relax, look around, make a call.',
      'Default: Aggressive.'
    ],
    assignment: {
      title: 'Extreme Ownership Audit',
      description: 'Identify where you\'ve been avoiding ownership and take it back.',
      tasks: [
        'List 3 current problems in your work/business where you\'ve blamed others or circumstances',
        'For each, write: "I am responsible because..." and identify what YOU could have done differently',
        'Identify one plan or process that\'s too complex — simplify it to one page',
        'Find one area where you need to "lead up the chain" — draft that conversation',
        'Create your personal "standard" — what you will no longer tolerate from yourself'
      ]
    }
  },
  {
    week: 5,
    slug: 'who-not-how',
    title: 'Who Not How',
    author: 'Dan Sullivan',
    hook: 'Stop asking "How do I do this?" and start asking "Who can do this for me?"',
    theme: 'Delegation & Leverage',
    pages: 192,
    audioHours: '5h 30m',
    status: 'locked',
    summary: 'Strategic Coach founder Dan Sullivan reveals why high achievers are limited by their "how" mentality and how shifting to "who" thinking unlocks exponential growth.',
    whyUnconventional: 'Society celebrates the self-made myth. Sullivan shows why the most successful people outsource almost everything.',
    bigIdea: 'Every time you ask "How?" you limit yourself. Ask "Who?" instead and unlock unlimited growth.',
    bigIdeaQuote: 'When you know who, you don\'t need to know how.',
    keyConcepts: [
      {
        title: 'The Who vs. How Mindset',
        description: '"How" keeps you stuck doing everything. "Who" frees you to focus on your genius.'
      },
      {
        title: 'Self-Managing Companies',
        description: 'Build systems where others run the operations while you focus on vision.'
      },
      {
        title: 'Unique Ability',
        description: 'Identify what only you can do — delegate or delete everything else.'
      },
      {
        title: 'Transformational Leadership',
        description: 'Your job isn\'t to do the work. It\'s to develop people who do the work better than you could.'
      }
    ],
    caseStudy: {
      title: 'The Entrepreneurial Time Trap',
      content: 'Most entrepreneurs start by doing everything themselves. They become experts at "how." But this expertise becomes a prison. The more capable they are, the more they do themselves. The shift happens when they realize: the goal isn\'t to be the most capable person — it\'s to build a team of capable people. The founder\'s job is to find "Whos" and give them clear outcomes.'
    },
    keyPrinciples: [
      {
        title: 'Replace How with Who',
        description: 'Before solving any problem, ask: Who is already good at this?'
      },
      {
        title: 'Know Your Unique Ability',
        description: 'Only do what only you can do. Everything else is a "Who" opportunity.'
      },
      {
        title: 'Invest in Whos',
        description: 'Pay for the best people. They\'re cheaper than your time.'
      },
      {
        title: 'Give Outcomes, Not Tasks',
        description: 'Tell your Whos what success looks like, then get out of their way.'
      },
      {
        title: 'Build Who Networks',
        description: 'Your success is determined by the quality of your Who collection.'
      }
    ],
    quotes: [
      'When you know who, you don\'t need to know how.',
      'Procrastination is wisdom — it tells you that you need a Who.',
      'Your Unique Ability is what only you can do.',
      'The best use of your time is finding and developing Whos.',
      'Freedom comes from Whos, not Hows.'
    ],
    assignment: {
      title: 'Who Not How Inventory',
      description: 'Identify where you\'re trapped in "How" and find your "Whos."',
      tasks: [
        'List everything you do in a typical week — categorize as "Unique Ability," "Excellent," "Competent," or "Incompetent"',
        'For everything not in "Unique Ability," identify a potential "Who"',
        'Choose 3 tasks to delegate this month — write the outcome clearly for each',
        'Identify 5 "Whos" you need but don\'t have yet',
        'Calculate: What\'s your hourly rate? What tasks are you doing below that rate?'
      ]
    }
  },
  {
    week: 6,
    slug: 'the-ride-of-a-lifetime',
    title: 'The Ride of a Lifetime',
    author: 'Bob Iger',
    hook: 'How Disney\'s CEO acquired Pixar, Marvel, Lucasfilm, and Fox — and the leadership principles behind the magic.',
    theme: 'Transformational Leadership',
    pages: 272,
    audioHours: '9h 15m',
    status: 'locked',
    summary: 'Bob Iger transformed Disney from a struggling legacy company into the most valuable entertainment business on Earth through bold acquisitions and principled leadership.',
    whyUnconventional: 'Most CEOs optimize existing businesses. Iger repeatedly bet the company on transformative acquisitions that skeptics said would fail.',
    bigIdea: 'Great leaders take big swings, treat people with respect, and never lose sight of quality.',
    bigIdeaQuote: 'The riskiest thing we can do is just maintain the status quo.',
    keyConcepts: [
      {
        title: 'The Three Priorities',
        description: 'Iger distilled Disney\'s strategy to just three priorities — and repeated them relentlessly.'
      },
      {
        title: 'Bold Acquisitions',
        description: 'Sometimes you have to buy what you can\'t build. Pay for quality.'
      },
      {
        title: 'Respect for Creatives',
        description: 'Don\'t let corporate bureaucracy crush creative genius.'
      },
      {
        title: 'Long-Term Thinking',
        description: 'Make decisions for where you want to be in 10 years, not next quarter.'
      }
    ],
    caseStudy: {
      title: 'The Pixar Acquisition',
      content: 'When Iger became CEO, Disney Animation was a disaster — producing flops while Pixar dominated. Instead of trying to fix the unfixable, Iger made a bold move: buy Pixar for $7.4 billion. Critics said he was overpaying. But Iger saw what they didn\'t: Pixar had both the technology AND the creative culture Disney needed. He paid premium for quality, protected Pixar\'s culture, and put Pixar\'s leaders in charge of all Disney Animation. The result: a creative renaissance.'
    },
    keyPrinciples: [
      {
        title: 'Simplify Your Strategy',
        description: 'If you can\'t explain your strategy in three priorities, it\'s too complex.'
      },
      {
        title: 'Take Big Swings',
        description: 'Small moves yield small results. Be willing to bet big on transformative opportunities.'
      },
      {
        title: 'Protect Creative Culture',
        description: 'Great content comes from great cultures. Don\'t let bureaucracy kill creativity.'
      },
      {
        title: 'Treat People with Decency',
        description: 'Respect isn\'t weakness. It\'s how you get the best from people.'
      },
      {
        title: 'Quality is Non-Negotiable',
        description: 'Never sacrifice quality for speed or cost. Quality wins long-term.'
      }
    ],
    quotes: [
      'The riskiest thing we can do is just maintain the status quo.',
      'Don\'t let ambition get ahead of opportunity.',
      'Treating people with decency is not just an ethical thing. It\'s good business.',
      'Quality is the best business plan.',
      'If you want innovation, you need to give permission to fail.'
    ],
    assignment: {
      title: 'Transformational Leadership Plan',
      description: 'Identify your three priorities and one bold move.',
      tasks: [
        'Distill your strategy to exactly 3 priorities — write them in one sentence each',
        'Identify one "Pixar-level" acquisition or partnership that could transform your business',
        'Audit your culture: What bureaucracy is killing creativity? Plan to eliminate it.',
        'List 3 people you need to treat with more respect — plan specific actions',
        'Define your quality standard — what will you never compromise on?'
      ]
    }
  },
  {
    week: 7,
    slug: 'poor-charlies-almanack',
    title: 'Poor Charlie\'s Almanack',
    author: 'Charlie Munger',
    hook: '500 pages of mental models from Warren Buffett\'s partner — the best thinking toolkit ever assembled.',
    theme: 'Mental Models',
    pages: 548,
    audioHours: '14h 20m',
    status: 'locked',
    summary: 'Charlie Munger\'s collected wisdom on decision-making, investing, and life. This is the operating system for better thinking.',
    whyUnconventional: 'Business schools teach narrow specialization. Munger teaches "worldly wisdom" — pulling insights from every discipline to make better decisions.',
    bigIdea: 'You need a latticework of mental models from multiple disciplines. If you only have one tool, you\'ll distort reality to fit it.',
    bigIdeaQuote: 'To the man with only a hammer, every problem looks like a nail.',
    keyConcepts: [
      {
        title: 'Mental Models',
        description: 'Frameworks from multiple disciplines that help you understand reality.'
      },
      {
        title: 'Inversion',
        description: 'Instead of asking how to succeed, ask: What would guarantee failure? Then avoid that.'
      },
      {
        title: 'Circle of Competence',
        description: 'Know what you know. More importantly, know what you don\'t know.'
      },
      {
        title: 'Second-Order Thinking',
        description: 'Consider the consequences of the consequences.'
      }
    ],
    caseStudy: {
      title: 'Berkshire Hathaway\'s Decision Framework',
      content: 'Munger and Buffett make investment decisions using a multi-model approach. They don\'t just ask "Is this a good company?" They apply psychology (Will management behave rationally?), economics (Is there a durable moat?), physics (What are the constraints?), and probability (What are the odds of each scenario?). This multi-lens approach led to investments in GEICO, Coca-Cola, and Apple — and helped them avoid countless disasters.'
    },
    keyPrinciples: [
      {
        title: 'Build a Latticework',
        description: 'Collect mental models from every discipline. Connect them into a framework.'
      },
      {
        title: 'Invert, Always Invert',
        description: 'Many problems are best solved backward. Start with what you want to avoid.'
      },
      {
        title: 'Stay in Your Circle',
        description: 'Operate where you have genuine expertise. Expand the circle slowly.'
      },
      {
        title: 'Avoid Stupidity',
        description: 'It\'s easier to avoid stupidity than achieve brilliance. Focus on not being dumb.'
      },
      {
        title: 'Read Constantly',
        description: 'Fill your mind with the best thinking from every field.'
      }
    ],
    quotes: [
      'To the man with only a hammer, every problem looks like a nail.',
      'Invert, always invert.',
      'In my whole life, I have known no wise people who didn\'t read all the time — none, zero.',
      'Knowing what you don\'t know is more useful than being brilliant.',
      'The best thing a human being can do is to help another human being know more.'
    ],
    assignment: {
      title: 'Mental Model Collection',
      description: 'Build the foundation of your latticework of mental models.',
      tasks: [
        'List 10 mental models you already use (even if you didn\'t know they had names)',
        'Learn 3 new models from different disciplines (psychology, physics, biology, economics)',
        'Apply "inversion" to your biggest current challenge — what would guarantee failure?',
        'Define your circle of competence — what do you genuinely know? What do you not?',
        'Create a "mistakes journal" — document errors to avoid repeating them'
      ]
    }
  },
  {
    week: 8,
    slug: 'the-almanack-of-naval-ravikant',
    title: 'The Almanack of Naval Ravikant',
    author: 'Eric Jorgenson',
    hook: 'A guide to wealth and happiness from Silicon Valley\'s most interesting thinker.',
    theme: 'Wealth & Happiness',
    pages: 244,
    audioHours: '4h 30m',
    status: 'locked',
    summary: 'A collection of Naval Ravikant\'s wisdom on building wealth, finding happiness, and living a meaningful life. Distilled from years of tweets, podcasts, and interviews.',
    whyUnconventional: 'Naval rejects the trade-off between money and meaning. He shows how to get rich without getting lucky — and be happy regardless of outcomes.',
    bigIdea: 'Seek wealth, not money or status. Build leverage through code, media, or capital. Happiness is a skill you can develop.',
    bigIdeaQuote: 'Seek wealth, not money or status. Wealth is having assets that earn while you sleep.',
    keyConcepts: [
      {
        title: 'Specific Knowledge',
        description: 'Knowledge you can\'t be trained for — it\'s learned through apprenticeship and obsession.'
      },
      {
        title: 'Leverage',
        description: 'Code, media, and capital let you multiply your output without multiplying your input.'
      },
      {
        title: 'Judgment',
        description: 'The most valuable skill. Knowing what to do when there\'s no playbook.'
      },
      {
        title: 'Happiness as a Skill',
        description: 'Happiness isn\'t something that happens to you. It\'s something you practice.'
      }
    ],
    caseStudy: {
      title: 'Naval\'s Path',
      content: 'Naval started as a broke immigrant. Through relentless learning and strategic positioning, he became one of Silicon Valley\'s most successful angel investors (early in Twitter, Uber, and 100+ companies). But his real insight wasn\'t about startups — it was realizing that wealth and happiness are skills, not outcomes. You can systematically develop both.'
    },
    keyPrinciples: [
      {
        title: 'Productize Yourself',
        description: 'Find what you\'re uniquely good at, then figure out how to scale it.'
      },
      {
        title: 'Own Equity',
        description: 'You won\'t get rich renting out your time. Own a piece of a business.'
      },
      {
        title: 'Learn to Sell, Learn to Build',
        description: 'If you can do both, you\'ll be unstoppable.'
      },
      {
        title: 'Play Long-Term Games',
        description: 'Play games where compound interest — in relationships and money — works for you.'
      },
      {
        title: 'Desire is Suffering',
        description: 'Happiness is the state when nothing is missing. Reduce desires, increase happiness.'
      }
    ],
    quotes: [
      'Seek wealth, not money or status.',
      'Learn to sell. Learn to build. If you can do both, you will be unstoppable.',
      'Specific knowledge is knowledge that you cannot be trained for.',
      'The most important skill for getting rich is becoming a perpetual learner.',
      'A fit body, a calm mind, a house full of love. These things cannot be bought — they must be earned.'
    ],
    assignment: {
      title: 'Wealth & Leverage Audit',
      description: 'Identify your path to building lasting wealth.',
      tasks: [
        'Define your "specific knowledge" — what are you obsessed with that others aren\'t?',
        'Audit your leverage: Do you have code, media, or capital working for you while you sleep?',
        'Identify one way to "productize yourself" — package your skills into something scalable',
        'List 3 long-term games you should be playing (relationships, skills, investments)',
        'Happiness inventory: What desires are causing you suffering? Which can you release?'
      ]
    }
  },
  {
    week: 9,
    slug: 'breaking-the-habit-of-being-yourself',
    title: 'Breaking the Habit of Being Yourself',
    author: 'Joe Dispenza',
    hook: 'The neuroscience of why you\'re stuck — and the meditation practice to rewire your brain.',
    theme: 'Neuroscience of Change',
    pages: 360,
    audioHours: '10h 45m',
    status: 'locked',
    summary: 'Dr. Joe Dispenza combines neuroscience, quantum physics, and meditation to explain why changing your mind literally changes your life — and how to do it.',
    whyUnconventional: 'Business books assume you just need better strategies. Dispenza shows that your identity and neural patterns must change first — or you\'ll sabotage every strategy.',
    bigIdea: 'Your personality creates your personal reality. To change your life, you must become a different person — literally rewire your brain.',
    bigIdeaQuote: 'If you want a new outcome, you will have to break the habit of being yourself.',
    keyConcepts: [
      {
        title: 'The Habit of Being Yourself',
        description: 'Your thoughts, feelings, and behaviors form a loop that reinforces your current identity.'
      },
      {
        title: 'Neuroplasticity',
        description: 'Your brain can change at any age. New thoughts create new neural pathways.'
      },
      {
        title: 'Mind-Body Connection',
        description: 'Your body becomes addicted to certain emotional states. Change requires breaking that addiction.'
      },
      {
        title: 'Meditation as Rewiring',
        description: 'Focused meditation isn\'t just relaxation — it\'s active brain reprogramming.'
      }
    ],
    caseStudy: {
      title: 'The Placebo Effect Expanded',
      content: 'Dispenza documents cases of people healing "incurable" diseases through meditation and mental rehearsal. His research shows that the brain doesn\'t distinguish between a real experience and one vividly imagined. By mentally rehearsing a new identity — new thoughts, emotions, behaviors — you can literally rewire your brain to support that new reality. The implications for business: Your current results are products of your current identity. New results require a new you.'
    },
    keyPrinciples: [
      {
        title: 'Change Requires Discomfort',
        description: 'Breaking identity patterns feels like dying. Push through anyway.'
      },
      {
        title: 'Thoughts Create Reality',
        description: 'What you focus on expands. Direct your attention intentionally.'
      },
      {
        title: 'Emotion is the Language of the Body',
        description: 'Your body believes your emotional state. Give it emotions of your future self.'
      },
      {
        title: 'Meditate Daily',
        description: 'Meditation isn\'t optional — it\'s how you reprogram your subconscious.'
      },
      {
        title: 'Become Before You Have',
        description: 'Be the person who has what you want. The having follows the being.'
      }
    ],
    quotes: [
      'If you want a new outcome, you will have to break the habit of being yourself.',
      'Your personality creates your personal reality.',
      'The quantum field responds not to what we want; it responds to who we are being.',
      'Knowledge is nothing without action.',
      'We cannot create a new future while we\'re living in our past.'
    ],
    assignment: {
      title: 'Identity Rewiring Plan',
      description: 'Map your current identity and design your future self.',
      tasks: [
        'Document your current "identity loop" — habitual thoughts, emotions, and behaviors',
        'Define your future self: Who must you become to achieve your biggest goal?',
        'Identify 3 emotional addictions holding you back (anger, anxiety, self-doubt, etc.)',
        'Start a daily meditation practice — minimum 15 minutes',
        'Practice "mental rehearsal" — vividly imagine being your future self for 10 min daily'
      ]
    }
  },
  {
    week: 10,
    slug: 'illusions',
    title: 'Illusions',
    author: 'Richard Bach',
    hook: 'A handbook for reluctant messiahs — questioning everything you think you know.',
    theme: 'Beliefs & Reality',
    pages: 192,
    audioHours: '3h 15m',
    status: 'locked',
    summary: 'A mystical fable about a barnstorming pilot who meets a messiah who quit. A profound exploration of belief, reality, and the limits we place on ourselves.',
    whyUnconventional: 'In a curriculum of hard-nosed business books, Illusions forces you to examine the beliefs underlying all your ambitions. What do you believe is impossible? Why?',
    bigIdea: 'You are never given a wish without also being given the power to make it come true. The limits you perceive are illusions.',
    bigIdeaQuote: 'Argue for your limitations, and sure enough, they\'re yours.',
    keyConcepts: [
      {
        title: 'The Handbook',
        description: 'Open any book to any page and you\'ll find what you need. Truth is everywhere.'
      },
      {
        title: 'Arguing for Limitations',
        description: 'When you defend why you can\'t do something, you make that limitation real.'
      },
      {
        title: 'Reality as Projection',
        description: 'Your beliefs about what\'s possible shape what actually happens.'
      },
      {
        title: 'The Reluctant Messiah',
        description: 'Everyone has gifts to share. Most are too scared to share them.'
      }
    ],
    caseStudy: {
      title: 'The Vaporizing of Limits',
      content: 'Throughout Illusions, the messiah Donald Shimoda performs "impossible" feats — walking through walls, appearing and disappearing, healing. But he insists these aren\'t miracles. They\'re simply what happens when you stop believing in limitations. The business parallel: Every industry has "impossible" things that are actually just consensus illusions. The entrepreneurs who change industries are the ones who refuse to accept these illusions.'
    },
    keyPrinciples: [
      {
        title: 'Question Everything',
        description: 'The limits you accept are the limits you live within.'
      },
      {
        title: 'You Teach What You Need to Learn',
        description: 'Your greatest teachings come from your deepest struggles.'
      },
      {
        title: 'What You Believe, You Live',
        description: 'Change your beliefs, change your life.'
      },
      {
        title: 'Take Nothing Seriously',
        description: 'Life is a game. Play it, but don\'t be imprisoned by it.'
      },
      {
        title: 'Trust Your Path',
        description: 'You\'re exactly where you need to be.'
      }
    ],
    quotes: [
      'Argue for your limitations, and sure enough, they\'re yours.',
      'You are never given a wish without also being given the power to make it come true.',
      'Your only obligation in any lifetime is to be true to yourself.',
      'What the caterpillar calls the end of the world, the master calls a butterfly.',
      'Learning is finding out what you already know.'
    ],
    assignment: {
      title: 'Belief Audit',
      description: 'Identify and challenge the limiting beliefs holding you back.',
      tasks: [
        'List 5 things you believe are "impossible" in your business or career',
        'For each, ask: Is this actually impossible, or just difficult/unconventional?',
        'Identify 3 beliefs about yourself that might be "illusions" — where did they come from?',
        'Find one person who achieved something you believe is impossible for you — study how',
        'Practice the "Handbook Test" — open a random book for guidance on your biggest challenge'
      ]
    }
  },
  {
    week: 11,
    slug: 'setting-the-table',
    title: 'Setting the Table',
    author: 'Danny Meyer',
    hook: 'How enlightened hospitality built a restaurant empire — and can transform any business.',
    theme: 'Hospitality Excellence',
    pages: 320,
    audioHours: '10h 30m',
    status: 'locked',
    summary: 'Danny Meyer built Shake Shack and a restaurant empire on one principle: hospitality that makes people feel seen. This is his system for creating fanatical customer loyalty.',
    whyUnconventional: 'Most businesses focus on products and efficiency. Meyer shows that HOW you make people feel matters more than what you sell.',
    bigIdea: 'Hospitality is not service. Service is delivering the product. Hospitality is how you make people feel while delivering it.',
    bigIdeaQuote: 'The most successful businesses make their customers feel like they are being let in on something special.',
    keyConcepts: [
      {
        title: 'Hospitality vs. Service',
        description: 'Service is a monologue — what we do. Hospitality is a dialogue — how we make you feel.'
      },
      {
        title: 'Enlightened Hospitality',
        description: 'Put employees first, then customers, then community, then investors.'
      },
      {
        title: 'Constant, Gentle Pressure',
        description: 'Excellence comes from relentless attention to small things.'
      },
      {
        title: 'The 51% Solution',
        description: 'Hire for emotional intelligence and warmth. Skills can be taught; attitude can\'t.'
      }
    ],
    caseStudy: {
      title: 'Union Square Cafe\'s Resurrection',
      content: 'Union Square Cafe was losing its lease after 30 years. Most restaurants don\'t survive a move. Meyer did something radical: he asked his most loyal customers to help design the new space. He turned a potential disaster into a love letter to the community. The new location became his highest-grossing restaurant. The lesson: when you genuinely care about people, they\'ll move mountains for you.'
    },
    keyPrinciples: [
      {
        title: 'Employees First',
        description: 'Take care of your people first. They\'ll take care of customers.'
      },
      {
        title: 'Make People Feel Seen',
        description: 'Remember names, preferences, occasions. Details create magic.'
      },
      {
        title: 'Write a Good Last Chapter',
        description: 'The ending of any experience matters most. Nail the goodbye.'
      },
      {
        title: 'Collect Dots, Connect Dots',
        description: 'Pay attention to everything. The best hospitality comes from noticing.'
      },
      {
        title: 'Mistakes Are Gifts',
        description: 'How you handle mistakes defines you more than perfection ever could.'
      }
    ],
    quotes: [
      'The most successful businesses make their customers feel like they are being let in on something special.',
      'Service is a monologue. Hospitality is a dialogue.',
      'The only way to be truly original is to be relentlessly specific.',
      'If you can\'t make a genuine emotional connection, you\'re not in the hospitality business.',
      'Constant, gentle pressure is the best path to excellence.'
    ],
    assignment: {
      title: 'Hospitality Transformation',
      description: 'Redesign your customer experience with hospitality principles.',
      tasks: [
        'Map your customer journey — where do they feel like transactions vs. guests?',
        'Apply the "51% Solution" — evaluate your team for emotional intelligence',
        'Design 3 "small touch" hospitality moments you can add to your business',
        'Create a "last chapter" review — how does your customer experience end?',
        'Develop a mistakes protocol — how will you turn problems into relationship builders?'
      ]
    }
  },
  {
    week: 12,
    slug: 'unreasonable-hospitality',
    title: 'Unreasonable Hospitality',
    author: 'Will Guidara',
    hook: 'How the world\'s best restaurant gave hot dogs to guests — and why that mattered.',
    theme: 'Legendary Service',
    pages: 288,
    audioHours: '8h 45m',
    status: 'locked',
    summary: 'Will Guidara took Eleven Madison Park from good to the #1 restaurant in the world by obsessing over unreasonable hospitality — going far beyond what\'s expected.',
    whyUnconventional: 'Most businesses try to standardize service. Guidara shows that legendary businesses do the unreasonable — the personal, unexpected things that can\'t be scaled.',
    bigIdea: 'The goal isn\'t meeting expectations. It\'s shattering them by caring more than is reasonable.',
    bigIdeaQuote: 'Being unreasonable is the only way to break through the noise.',
    keyConcepts: [
      {
        title: 'Unreasonable Hospitality',
        description: 'Going beyond what\'s expected — doing things that don\'t scale, because they matter.'
      },
      {
        title: 'The Hot Dog Story',
        description: 'Guests mentioned wanting a NYC hot dog. Guidara sent a runner. It became their most memorable moment.'
      },
      {
        title: 'Dreamweavers',
        description: 'A dedicated person whose job is creating magical moments.'
      },
      {
        title: 'The Rule of 95/5',
        description: 'Manage 95% of your business for profitability. Use 5% for magic.'
      }
    ],
    caseStudy: {
      title: 'The #1 Restaurant in the World',
      content: 'When Guidara took over, Eleven Madison Park was a respected but not exceptional restaurant. He noticed the food was incredible, but the experience was cold. His solution: obsess over making guests feel special. He created a "Dreamweaver" role — someone whose only job was listening for opportunities to create personalized magic. The result: Eleven Madison Park became the #1 restaurant in the world, not because of the food alone, but because of how it made people feel.'
    },
    keyPrinciples: [
      {
        title: 'Be Unreasonable',
        description: 'Reasonable hospitality is forgettable. Unreasonable hospitality creates legends.'
      },
      {
        title: 'Listen for Opportunities',
        description: 'Every guest gives you hints about how to delight them. Pay attention.'
      },
      {
        title: 'Invest in Magic',
        description: 'Budget time and money specifically for unexpected delights.'
      },
      {
        title: 'One Size Fits One',
        description: 'The best hospitality is personal. Customize everything possible.'
      },
      {
        title: 'Make Work Mean Something',
        description: 'People want to be part of something special. Give them that.'
      }
    ],
    quotes: [
      'Being unreasonable is the only way to break through the noise.',
      'The magic isn\'t in the big gestures. It\'s in the small ones.',
      'One size fits one.',
      'Work should be meaningful. If it isn\'t, you\'re doing it wrong.',
      'The hot dog cost $2. The memory is priceless.'
    ],
    assignment: {
      title: 'Unreasonable Hospitality Plan',
      description: 'Design unreasonable touches for your customers.',
      tasks: [
        'Identify 5 moments where you could go beyond reasonable expectations',
        'Create a "Dreamweaver" system — how will you capture opportunities to delight?',
        'Design 3 "hot dog moments" — small, personalized gestures that would surprise customers',
        'Calculate your 95/5 budget — what\'s 5% of your revenue you can invest in magic?',
        'Interview 3 customers — what would make them tell their friends about you?'
      ]
    }
  },
  {
    week: 13,
    slug: 'how-to-win-friends-and-influence-people',
    title: 'How to Win Friends and Influence People',
    author: 'Dale Carnegie',
    hook: 'The timeless classic on human nature — still the most important business skill.',
    theme: 'Interpersonal Mastery',
    pages: 288,
    audioHours: '7h 15m',
    status: 'locked',
    summary: 'Dale Carnegie\'s 1936 masterpiece has sold 30 million copies because it contains timeless truths about human nature and influence.',
    whyUnconventional: 'In an age of automation and AI, human connection becomes the ultimate competitive advantage. This 90-year-old book is more relevant than ever.',
    bigIdea: 'You can make more friends in two months by becoming genuinely interested in other people than in two years by trying to get them interested in you.',
    bigIdeaQuote: 'A person\'s name is to that person the sweetest sound in any language.',
    keyConcepts: [
      {
        title: 'Don\'t Criticize, Condemn, or Complain',
        description: 'Criticism puts people on the defensive. It never creates lasting change.'
      },
      {
        title: 'Give Honest, Sincere Appreciation',
        description: 'Everyone craves appreciation. Give it genuinely and watch relationships transform.'
      },
      {
        title: 'Arouse an Eager Want',
        description: 'Talk in terms of what the other person wants, not what you want.'
      },
      {
        title: 'Become Genuinely Interested',
        description: 'Interest in others is not a technique — it\'s a way of being.'
      }
    ],
    caseStudy: {
      title: 'The Century-Long Bestseller',
      content: 'How to Win Friends has sold 30+ million copies across a century — through depression, wars, technological revolution, and social upheaval. Why? Because it addresses something that never changes: human nature. People still want to feel important. They still respond to genuine interest. They still make decisions emotionally and justify them logically. The book endures because people endure.'
    },
    keyPrinciples: [
      {
        title: 'Never Criticize',
        description: 'Criticism creates resentment, not change. Find another way.'
      },
      {
        title: 'Be Interested, Not Interesting',
        description: 'Ask questions. Listen. Make the conversation about them.'
      },
      {
        title: 'Use Names',
        description: 'Remember and use people\'s names. It\'s the sweetest sound to them.'
      },
      {
        title: 'Let Others Feel Important',
        description: 'Everyone has an invisible sign: "Make me feel important."'
      },
      {
        title: 'Begin with Praise',
        description: 'If you must give feedback, start with genuine appreciation.'
      }
    ],
    quotes: [
      'A person\'s name is to that person the sweetest sound in any language.',
      'You can make more friends in two months by becoming interested in other people than in two years by trying to get other people interested in you.',
      'Any fool can criticize, condemn and complain — and most fools do.',
      'Talk to someone about themselves and they\'ll listen for hours.',
      'The only way to get the best of an argument is to avoid it.'
    ],
    assignment: {
      title: 'Interpersonal Skills Intensive',
      description: 'Practice the timeless principles of human connection.',
      tasks: [
        'For one week, eliminate all criticism, condemnation, and complaints',
        'Practice the "interested not interesting" principle — 5 conversations where you only ask questions',
        'Start a name journal — write down every new name you learn and one fact about the person',
        'Give 3 genuine, specific appreciations every day for a week',
        'Identify your most difficult relationship — apply one Carnegie principle and document results'
      ]
    }
  },
  {
    week: 14,
    slug: 'let-my-people-go-surfing',
    title: 'Let My People Go Surfing',
    author: 'Yvon Chouinard',
    hook: 'How the founder of Patagonia built a billion-dollar company by breaking every rule.',
    theme: 'Purpose-Driven Business',
    pages: 272,
    audioHours: '8h 30m',
    status: 'locked',
    summary: 'Yvon Chouinard built Patagonia into a $3 billion company while prioritizing environment, employees, and purpose over growth.',
    whyUnconventional: 'Chouinard proves you don\'t have to choose between profit and purpose. In fact, purpose may be the ultimate competitive advantage.',
    bigIdea: 'The more you focus on doing the right thing, the more profitable you become — not in spite of your values, but because of them.',
    bigIdeaQuote: 'I\'ve been a businessman for almost 60 years. It\'s as difficult for me to say those words as it is for someone to admit being an alcoholic.',
    keyConcepts: [
      {
        title: 'Let My People Go Surfing',
        description: 'Flexible work policies that trust employees to get work done.'
      },
      {
        title: '1% for the Planet',
        description: 'Donate 1% of sales (not profits) to environmental causes.'
      },
      {
        title: 'Quality as Environmental Strategy',
        description: 'Build products that last forever. It\'s better for the planet AND business.'
      },
      {
        title: 'Don\'t Run on Rat Cheese',
        description: 'Don\'t grow just for growth\'s sake. Grow only to do more good.'
      }
    ],
    caseStudy: {
      title: 'The "Don\'t Buy This Jacket" Campaign',
      content: 'On Black Friday 2011, Patagonia ran a full-page ad in the New York Times: "Don\'t Buy This Jacket." It detailed the environmental cost of their best-selling fleece and urged customers to buy only what they need. Critics predicted disaster. Sales increased 30%. Why? Because authenticity is magnetic. When you stand for something real, the right customers find you.'
    },
    keyPrinciples: [
      {
        title: 'Purpose Before Profit',
        description: 'Define what you stand for. The money follows meaning.'
      },
      {
        title: 'Quality is Sustainability',
        description: 'Make products so good they last. Customers and planet both win.'
      },
      {
        title: 'Trust Your People',
        description: 'Give employees autonomy. They\'ll give you their best work.'
      },
      {
        title: 'Challenge the Industry',
        description: 'Break conventions if they don\'t serve your values.'
      },
      {
        title: 'Grow Wisely',
        description: 'Growth isn\'t always good. Grow only in ways aligned with your mission.'
      }
    ],
    quotes: [
      'I\'ve been a businessman for almost 60 years. It\'s as difficult for me to say those words as it is for someone to admit being an alcoholic.',
      'The more you know, the less you need.',
      'Let my people go surfing.',
      'If you want to understand the entrepreneur, study the juvenile delinquent.',
      'Profit is what happens when you do everything else right.'
    ],
    assignment: {
      title: 'Purpose Integration',
      description: 'Align your business with deeper meaning.',
      tasks: [
        'Define your company\'s purpose beyond profit in one sentence',
        'Identify 3 ways your values are OR aren\'t integrated into your operations',
        'Design a "1% pledge" — what would you donate 1% of sales to?',
        'Audit your quality: Does your product deserve to exist for 10+ years?',
        'Create one unconventional policy that puts employees first (your "let them surf" moment)'
      ]
    }
  },
  {
    week: 15,
    slug: 'your-money-or-your-life',
    title: 'Your Money or Your Life',
    author: 'Vicki Robin',
    hook: 'The book that launched the FIRE movement — redefining wealth as freedom, not accumulation.',
    theme: 'Financial Independence',
    pages: 368,
    audioHours: '9h 15m',
    status: 'locked',
    summary: 'Vicki Robin\'s classic challenges you to examine your relationship with money and design a life where work is optional.',
    whyUnconventional: 'Most business education teaches you to make more money. Robin asks: Why? What\'s enough? When does the chase become the prison?',
    bigIdea: 'You trade your life energy for money. Track that exchange carefully, and you\'ll realize most spending isn\'t worth your life.',
    bigIdeaQuote: 'Money is something we choose to trade our life energy for.',
    keyConcepts: [
      {
        title: 'Life Energy',
        description: 'Money isn\'t just dollars — it\'s hours of your life. Calculate your true hourly wage.'
      },
      {
        title: 'The Fulfillment Curve',
        description: 'More spending brings more happiness — until it doesn\'t. Find your "enough."'
      },
      {
        title: 'The Crossover Point',
        description: 'When investment income exceeds expenses, work becomes optional.'
      },
      {
        title: 'Gazingus Pins',
        description: 'Those things you buy compulsively that never really satisfy. We all have them.'
      }
    ],
    caseStudy: {
      title: 'The Birth of FIRE',
      content: 'Your Money or Your Life, first published in 1992, launched what became the FIRE (Financial Independence, Retire Early) movement. Millions of people have used its principles to escape the work-spend treadmill. The core insight: most people never calculate what they\'re trading for money. When you do the math — really do it — many expenses become obviously not worth the life energy they cost.'
    },
    keyPrinciples: [
      {
        title: 'Calculate Your True Hourly Wage',
        description: 'Include commute, decompression, work clothes. Your real wage is lower than you think.'
      },
      {
        title: 'Track Every Penny',
        description: 'Awareness transforms behavior. Know exactly where your money goes.'
      },
      {
        title: 'Find Your Enough',
        description: 'More isn\'t always better. Define what enough looks like for you.'
      },
      {
        title: 'Invest the Difference',
        description: 'The gap between earning and spending, invested wisely, buys freedom.'
      },
      {
        title: 'Separate Income from Work',
        description: 'The goal is choice: working because you want to, not because you have to.'
      }
    ],
    quotes: [
      'Money is something we choose to trade our life energy for.',
      'The key is not to prioritize what\'s on your schedule, but to schedule your priorities.',
      'Enough for our needs is so much less than enough for our greed.',
      'Financial Independence is having an income sufficient for your basic needs and comforts from a source other than paid employment.',
      'The less you need, the more freedom you have.'
    ],
    assignment: {
      title: 'Financial Independence Roadmap',
      description: 'Design your path to freedom.',
      tasks: [
        'Calculate your TRUE hourly wage (include all work-related time and expenses)',
        'Track every expense for one week — categorize by "worth the life energy" vs. not',
        'Define YOUR "enough" — what would a fulfilling life cost monthly?',
        'Calculate your Crossover Point — when could investment income cover expenses?',
        'Identify your "Gazingus Pins" — what do you buy compulsively that doesn\'t satisfy?'
      ]
    }
  }
];

// Helper functions
export function getBookBySlug(slug: string): Book | undefined {
  return books.find(book => book.slug === slug);
}

export function getBookByWeek(week: number): Book | undefined {
  return books.find(book => book.week === week);
}

export function getActiveBooks(): Book[] {
  return books.filter(book => book.status === 'active');
}

export function getLockedBooks(): Book[] {
  return books.filter(book => book.status === 'locked');
}

export function getCompletedBooks(): Book[] {
  return books.filter(book => book.status === 'completed');
}

export function getAllSlugs(): string[] {
  return books.map(book => book.slug);
}
