// tailwind.config.ts
// Unconventional Wisdom - Tailwind Configuration

import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        midnight: '#0a0a0a',
        charcoal: '#111111',
        slate: '#1a1a1a',
        gold: {
          DEFAULT: '#c9a227',
          light: '#e8c547',
          dark: '#a68520',
        },
        marble: {
          DEFAULT: '#f5f5f0',
          muted: 'rgba(245, 245, 240, 0.7)',
          subtle: 'rgba(245, 245, 240, 0.4)',
        },
      },
      fontFamily: {
        serif: ['Playfair Display', 'Georgia', 'serif'],
        sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
      },
      fontSize: {
        '2xs': '0.625rem',
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
        '128': '32rem',
      },
      borderRadius: {
        '2xl': '1rem',
        '3xl': '1.5rem',
      },
      boxShadow: {
        'gold': '0 0 20px rgba(201, 162, 39, 0.3)',
        'gold-lg': '0 0 40px rgba(201, 162, 39, 0.4)',
        'inner-gold': 'inset 0 0 20px rgba(201, 162, 39, 0.1)',
      },
      backgroundImage: {
        'gradient-gold': 'linear-gradient(135deg, #c9a227 0%, #e8c547 100%)',
        'gradient-gold-dark': 'linear-gradient(135deg, #a68520 0%, #c9a227 100%)',
        'gradient-radial': 'radial-gradient(ellipse at center, var(--tw-gradient-stops))',
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-out forwards',
        'shimmer': 'shimmer 2s infinite',
        'pulse-gold': 'pulse-gold 2s infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        'pulse-gold': {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(201, 162, 39, 0.4)' },
          '50%': { boxShadow: '0 0 20px 10px rgba(201, 162, 39, 0)' },
        },
      },
      typography: {
        DEFAULT: {
          css: {
            color: '#f5f5f0',
            a: {
              color: '#c9a227',
              '&:hover': {
                color: '#e8c547',
              },
            },
            h1: {
              color: '#f5f5f0',
              fontFamily: 'Playfair Display, Georgia, serif',
            },
            h2: {
              color: '#f5f5f0',
              fontFamily: 'Playfair Display, Georgia, serif',
            },
            h3: {
              color: '#f5f5f0',
              fontFamily: 'Playfair Display, Georgia, serif',
            },
            blockquote: {
              borderLeftColor: '#c9a227',
              color: 'rgba(245, 245, 240, 0.8)',
            },
            strong: {
              color: '#f5f5f0',
            },
            code: {
              color: '#c9a227',
            },
          },
        },
      },
    },
  },
  plugins: [],
};

export default config;
