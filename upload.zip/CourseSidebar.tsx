// components/CourseSidebar.tsx
// Unconventional Wisdom - Navigation Sidebar

'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { 
  Book, 
  Lock, 
  CheckCircle, 
  ChevronLeft, 
  ChevronRight,
  Home,
  Trophy,
  Settings,
  HelpCircle,
  LogOut
} from 'lucide-react';
import { books } from '@/lib/books';

interface CourseSidebarProps {
  currentSlug?: string;
}

export default function CourseSidebar({ currentSlug }: CourseSidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const pathname = usePathname();

  const completedCount = books.filter(b => b.status === 'completed').length;
  const totalBooks = books.length;
  const progressPercent = (completedCount / totalBooks) * 100;

  return (
    <aside 
      className={`
        sticky top-[73px] h-[calc(100vh-73px)] bg-[#0d0d0d] border-r border-[#c9a227]/10 
        transition-all duration-300 flex flex-col
        ${isCollapsed ? 'w-20' : 'w-72'}
      `}
    >
      {/* Toggle Button */}
      <button
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="absolute -right-3 top-6 w-6 h-6 bg-[#111111] border border-[#c9a227]/20 rounded-full flex items-center justify-center text-[#f5f5f0]/50 hover:text-[#c9a227] hover:border-[#c9a227]/50 transition-colors z-10"
      >
        {isCollapsed ? (
          <ChevronRight className="w-3 h-3" />
        ) : (
          <ChevronLeft className="w-3 h-3" />
        )}
      </button>

      {/* Progress Section */}
      {!isCollapsed && (
        <div className="p-6 border-b border-[#c9a227]/10">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-[#f5f5f0]/50 uppercase tracking-wider">Your Progress</span>
            <span className="text-sm text-[#c9a227]">{completedCount}/{totalBooks}</span>
          </div>
          <div className="w-full h-2 bg-[#1a1a1a] rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-[#c9a227] to-[#e8c547] rounded-full transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          {completedCount === totalBooks && (
            <p className="text-xs text-[#c9a227] mt-2 flex items-center gap-1">
              <Trophy className="w-3 h-3" />
              Eligible for $300 cashback!
            </p>
          )}
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4">
        {/* Home Link */}
        <div className="px-3 mb-2">
          <Link
            href="/learn"
            className={`
              flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors
              ${pathname === '/learn' 
                ? 'bg-[#c9a227]/10 text-[#c9a227]' 
                : 'text-[#f5f5f0]/50 hover:text-[#f5f5f0] hover:bg-[#111111]'
              }
            `}
          >
            <Home className="w-5 h-5 flex-shrink-0" />
            {!isCollapsed && <span className="text-sm">Library Home</span>}
          </Link>
        </div>

        {/* Divider */}
        <div className="h-px bg-[#c9a227]/10 mx-3 my-4" />

        {/* Week Labels */}
        {!isCollapsed && (
          <p className="px-6 text-xs text-[#f5f5f0]/30 uppercase tracking-wider mb-3">
            Curriculum
          </p>
        )}

        {/* Book List */}
        <div className="space-y-1 px-3">
          {books.map((book) => {
            const isActive = currentSlug === book.slug || pathname === `/learn/${book.slug}`;
            const isLocked = book.status === 'locked';
            const isCompleted = book.status === 'completed';

            return (
              <Link
                key={book.slug}
                href={isLocked ? '#' : `/learn/${book.slug}`}
                className={`
                  flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group
                  ${isActive 
                    ? 'bg-[#c9a227]/10 border border-[#c9a227]/30' 
                    : isLocked 
                      ? 'opacity-40 cursor-not-allowed' 
                      : 'hover:bg-[#111111]'
                  }
                `}
                onClick={(e) => isLocked && e.preventDefault()}
              >
                {/* Status Icon */}
                <div className={`
                  w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 transition-colors
                  ${isCompleted 
                    ? 'bg-[#c9a227] text-[#0a0a0a]' 
                    : isActive 
                      ? 'bg-[#c9a227]/20 text-[#c9a227] border border-[#c9a227]/30'
                      : isLocked 
                        ? 'bg-[#1a1a1a] text-[#f5f5f0]/20' 
                        : 'bg-[#1a1a1a] text-[#f5f5f0]/40 group-hover:text-[#c9a227]'
                  }
                `}>
                  {isCompleted ? (
                    <CheckCircle className="w-4 h-4" />
                  ) : isLocked ? (
                    <Lock className="w-3 h-3" />
                  ) : (
                    <span className="text-xs font-medium">{book.week}</span>
                  )}
                </div>

                {/* Book Info */}
                {!isCollapsed && (
                  <div className="flex-1 min-w-0">
                    <p className={`
                      text-sm truncate transition-colors
                      ${isActive 
                        ? 'text-[#c9a227]' 
                        : isLocked 
                          ? 'text-[#f5f5f0]/30' 
                          : 'text-[#f5f5f0]/70 group-hover:text-[#f5f5f0]'
                      }
                    `}>
                      {book.title}
                    </p>
                    <p className={`
                      text-xs truncate
                      ${isLocked ? 'text-[#f5f5f0]/20' : 'text-[#f5f5f0]/30'}
                    `}>
                      {book.author}
                    </p>
                  </div>
                )}
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Bottom Section */}
      <div className="border-t border-[#c9a227]/10 p-4">
        {!isCollapsed ? (
          <div className="space-y-1">
            <Link
              href="/help"
              className="flex items-center gap-3 px-3 py-2 rounded-lg text-[#f5f5f0]/40 hover:text-[#f5f5f0] hover:bg-[#111111] transition-colors"
            >
              <HelpCircle className="w-4 h-4" />
              <span className="text-sm">Help & Support</span>
            </Link>
            <Link
              href="/settings"
              className="flex items-center gap-3 px-3 py-2 rounded-lg text-[#f5f5f0]/40 hover:text-[#f5f5f0] hover:bg-[#111111] transition-colors"
            >
              <Settings className="w-4 h-4" />
              <span className="text-sm">Settings</span>
            </Link>
            <button
              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-[#f5f5f0]/40 hover:text-red-400 hover:bg-red-400/5 transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span className="text-sm">Sign Out</span>
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2">
            <Link
              href="/help"
              className="p-2 rounded-lg text-[#f5f5f0]/40 hover:text-[#f5f5f0] hover:bg-[#111111] transition-colors"
            >
              <HelpCircle className="w-5 h-5" />
            </Link>
            <Link
              href="/settings"
              className="p-2 rounded-lg text-[#f5f5f0]/40 hover:text-[#f5f5f0] hover:bg-[#111111] transition-colors"
            >
              <Settings className="w-5 h-5" />
            </Link>
          </div>
        )}
      </div>
    </aside>
  );
}
