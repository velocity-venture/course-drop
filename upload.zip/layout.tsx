// app/layout.tsx
// Unconventional Wisdom - Root Layout

import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Unconventional Wisdom | Private Athenaeum',
  description: '15 books that shaped how billionaires think. 16 weeks. $300 back if you finish.',
  keywords: ['business books', 'entrepreneurship', 'leadership', 'business education', 'course'],
  authors: [{ name: 'Sayada.ai' }],
  openGraph: {
    title: 'Unconventional Wisdom | Private Athenaeum',
    description: '15 books that shaped how billionaires think. 16 weeks. $300 back if you finish.',
    type: 'website',
    locale: 'en_US',
    siteName: 'Unconventional Wisdom',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Unconventional Wisdom | Private Athenaeum',
    description: '15 books that shaped how billionaires think. 16 weeks. $300 back if you finish.',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link 
          href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500&family=Inter:wght@300;400;500;600;700&display=swap" 
          rel="stylesheet" 
        />
      </head>
      <body className="bg-[#0a0a0a] text-[#f5f5f0] antialiased">
        {children}
      </body>
    </html>
  );
}
