// app/learn/page.tsx
// Unconventional Wisdom - Course Dashboard (Library View)

import Link from 'next/link';
import { Book, Lock, CheckCircle, Clock, BookOpen } from 'lucide-react';
import { books } from '@/lib/books';
import CourseSidebar from '@/components/CourseSidebar';

export default function LearnDashboard() {
  const totalWeeks = books.length;
  const completedWeeks = books.filter(b => b.status === 'completed').length;
  const activeWeeks = books.filter(b => b.status === 'active').length;
  
  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#f5f5f0]">
      {/* Header */}
      <header className="border-b border-[#c9a227]/20 bg-[#0a0a0a]/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[#c9a227] to-[#a68520] rounded-lg flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-[#0a0a0a]" />
            </div>
            <div>
              <h1 className="font-serif text-xl font-semibold tracking-wide">Unconventional Wisdom</h1>
              <p className="text-xs text-[#f5f5f0]/50 tracking-widest uppercase">Private Athenaeum</p>
            </div>
          </div>
          
          {/* Progress */}
          <div className="flex items-center gap-6">
            <div className="text-right">
              <p className="text-sm text-[#f5f5f0]/50">Progress</p>
              <p className="font-serif text-lg">
                <span className="text-[#c9a227]">{completedWeeks}</span>
                <span className="text-[#f5f5f0]/30"> / {totalWeeks} weeks</span>
              </p>
            </div>
            <div className="w-32 h-2 bg-[#1a1a1a] rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-[#c9a227] to-[#e8c547] rounded-full transition-all duration-500"
                style={{ width: `${(completedWeeks / totalWeeks) * 100}%` }}
              />
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <CourseSidebar />

        {/* Main Content */}
        <main className="flex-1 p-8">
          {/* Welcome Section */}
          <div className="mb-12">
            <h2 className="font-serif text-4xl font-light mb-4">
              Your <span className="text-[#c9a227] italic">Library</span>
            </h2>
            <p className="text-[#f5f5f0]/60 max-w-2xl leading-relaxed">
              15 books that shaped how billionaires think. Not summaries. Not highlights. 
              The full books, with assignments that force implementation.
            </p>
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-4 gap-6 mb-12">
            <div className="bg-[#111111] border border-[#c9a227]/10 rounded-xl p-6">
              <p className="text-[#f5f5f0]/40 text-sm uppercase tracking-wider mb-2">Total Books</p>
              <p className="font-serif text-3xl text-[#c9a227]">15</p>
            </div>
            <div className="bg-[#111111] border border-[#c9a227]/10 rounded-xl p-6">
              <p className="text-[#f5f5f0]/40 text-sm uppercase tracking-wider mb-2">Total Pages</p>
              <p className="font-serif text-3xl text-[#f5f5f0]">4,275</p>
            </div>
            <div className="bg-[#111111] border border-[#c9a227]/10 rounded-xl p-6">
              <p className="text-[#f5f5f0]/40 text-sm uppercase tracking-wider mb-2">Audio Hours</p>
              <p className="font-serif text-3xl text-[#f5f5f0]">115</p>
            </div>
            <div className="bg-[#111111] border border-[#c9a227]/10 rounded-xl p-6">
              <p className="text-[#f5f5f0]/40 text-sm uppercase tracking-wider mb-2">Cashback</p>
              <p className="font-serif text-3xl text-[#c9a227]">$300</p>
            </div>
          </div>

          {/* Book Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {books.map((book) => (
              <BookCard key={book.slug} book={book} />
            ))}
          </div>

          {/* Completion CTA */}
          <div className="mt-16 bg-gradient-to-r from-[#c9a227]/10 to-[#c9a227]/5 border border-[#c9a227]/20 rounded-2xl p-8 text-center">
            <h3 className="font-serif text-2xl mb-3">The $300 Completion Guarantee</h3>
            <p className="text-[#f5f5f0]/60 max-w-xl mx-auto mb-6">
              Complete all 15 books and submit your assignments by April 26, 2026. 
              We'll send you $300. No tricks. No fine print.
            </p>
            <div className="flex items-center justify-center gap-8 text-sm">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-[#c9a227]" />
                <span className="text-[#f5f5f0]/60">Read all 15 books</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-[#c9a227]" />
                <span className="text-[#f5f5f0]/60">Complete all assignments</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-[#c9a227]" />
                <span className="text-[#f5f5f0]/60">Submit by deadline</span>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

// Book Card Component
function BookCard({ book }: { book: typeof books[0] }) {
  const isLocked = book.status === 'locked';
  const isCompleted = book.status === 'completed';
  const isActive = book.status === 'active';

  return (
    <Link 
      href={isLocked ? '#' : `/learn/${book.slug}`}
      className={`
        group relative bg-[#111111] border rounded-xl overflow-hidden transition-all duration-300
        ${isLocked 
          ? 'border-[#333333] opacity-60 cursor-not-allowed' 
          : 'border-[#c9a227]/20 hover:border-[#c9a227]/50 hover:shadow-lg hover:shadow-[#c9a227]/5 cursor-pointer'
        }
        ${isCompleted ? 'border-[#c9a227]/40' : ''}
      `}
    >
      {/* Week Badge */}
      <div className={`
        absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-medium tracking-wider uppercase
        ${isCompleted 
          ? 'bg-[#c9a227] text-[#0a0a0a]' 
          : isActive 
            ? 'bg-[#c9a227]/20 text-[#c9a227] border border-[#c9a227]/30' 
            : 'bg-[#1a1a1a] text-[#f5f5f0]/40'
        }
      `}>
        {book.week === 0 ? 'Intro' : `Week ${book.week}`}
      </div>

      {/* Status Icon */}
      <div className="absolute top-4 right-4">
        {isCompleted && <CheckCircle className="w-5 h-5 text-[#c9a227]" />}
        {isLocked && <Lock className="w-5 h-5 text-[#f5f5f0]/20" />}
        {isActive && <Book className="w-5 h-5 text-[#c9a227]" />}
      </div>

      {/* Content */}
      <div className="pt-16 p-6">
        <h3 className={`
          font-serif text-xl mb-2 transition-colors duration-300
          ${isLocked ? 'text-[#f5f5f0]/40' : 'text-[#f5f5f0] group-hover:text-[#c9a227]'}
        `}>
          {book.title}
        </h3>
        
        <p className={`
          text-sm mb-4
          ${isLocked ? 'text-[#f5f5f0]/20' : 'text-[#f5f5f0]/50'}
        `}>
          by {book.author}
        </p>

        <p className={`
          text-sm leading-relaxed mb-4 line-clamp-2
          ${isLocked ? 'text-[#f5f5f0]/20' : 'text-[#f5f5f0]/40'}
        `}>
          {book.hook}
        </p>

        {/* Meta */}
        {book.week !== 0 && (
          <div className={`
            flex items-center gap-4 text-xs pt-4 border-t
            ${isLocked ? 'border-[#333333] text-[#f5f5f0]/20' : 'border-[#c9a227]/10 text-[#f5f5f0]/40'}
          `}>
            <div className="flex items-center gap-1">
              <Book className="w-3 h-3" />
              <span>{book.pages} pages</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              <span>{book.audioHours}</span>
            </div>
          </div>
        )}

        {/* Theme Tag */}
        <div className={`
          mt-4 inline-block px-3 py-1 rounded-full text-xs
          ${isLocked 
            ? 'bg-[#1a1a1a] text-[#f5f5f0]/20' 
            : 'bg-[#c9a227]/10 text-[#c9a227]'
          }
        `}>
          {book.theme}
        </div>
      </div>

      {/* Hover Overlay for Active */}
      {!isLocked && (
        <div className="absolute inset-0 bg-gradient-to-t from-[#c9a227]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
      )}
    </Link>
  );
}
